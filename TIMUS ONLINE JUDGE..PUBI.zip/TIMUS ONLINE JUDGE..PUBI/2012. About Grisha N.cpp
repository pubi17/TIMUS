#include<bits/stdc++.h>
using namespace std;
int main()
{
    int f;
    cin>>f;
    if(f>=7) {cout<<"YES"<<endl;}

    else {cout<<"NO"<<endl;}
    return 0;
}
