#include<bits/stdc++.h>
using namespace std;
int main()
{
    int k,a,i;
    vector<int>v;

    cin>>k;

    for(i=0; i<k; i++){cin>>a; v.push_back(a);}

    sort(v.begin(),v.end());

    int ans = 0;

    for(i=0; 2*i<k; ++i){
        ans += (v[i]+2)/2;
    }

    cout<<ans<<endl;
    return 0;
}
