#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,a,b,ans=0,res=0;
    cin>>n>>a>>b;
    ans=a*b;
    res=2*n*ans;
    cout<<res<<endl;
    return 0;

}
