#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,i,x,m;
   while( cin>>n ){
        if(n==0) break;
    int v[n+1];
    v[0]=0;
    v[1]=1;
    for( i=2; i<=n; i++)
    {
        x=i;

        if(i%2 == 0)
        {
            m=i/2;

            v[x] = v[m];
        }
        else{
            m=i/2;
            v[x]=v[m]+v[m+1];
        }
    }
    int max = v[0];
    for(i=1; i<=n; i++)
    {
        if(max < v[i]) max = v[i];
    }
    cout<<max<<endl;
   }
    return 0;
}
