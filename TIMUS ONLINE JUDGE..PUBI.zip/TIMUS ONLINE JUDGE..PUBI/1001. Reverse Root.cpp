#include<bits/stdc++.h>
using namespace std;
int main()
{
    vector<long long>v;
    long long a;
    ios::sync_with_stdio();
    while(scanf("%lld",&a) !=EOF)
    {
        v.push_back(a);
    }

    for(int i=v.size()-1;i>=0;i--)
    {
        cout<<fixed<<setprecision(4)<<sqrtl(v[i])<<endl;
    }
    return 0;
}
