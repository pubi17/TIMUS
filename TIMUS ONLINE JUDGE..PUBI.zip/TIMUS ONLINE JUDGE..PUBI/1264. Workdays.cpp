#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,m,i,j,c=0;
    ios::sync_with_stdio();
    cin>>n>>m;
    int a[n];
    for(i=0; i<n; i++)
    {
        for(j=0; j<=m; j++)
        {
            a[i]=j;
            c++;
        }
    }
    cout<<c<<endl;
    return 0;
}
