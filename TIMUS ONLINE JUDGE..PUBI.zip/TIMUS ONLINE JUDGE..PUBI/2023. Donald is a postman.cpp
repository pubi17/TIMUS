#include<bits/stdc++.h>
using namespace std;
char s1[10] = {'A','P','R'};
char s2[10] = {'B','M','S'};
char s3[10] = {'D','G','J','K','T','W'};

int check(string s)
{
    int i,c=0,c1;
   for (i=0;s1[i]!='\0';i++ )
   {
       if(s[0] == s1[i]){return c;}

   }
   c++;
   for(i=0; s2[i]!='\0'; i++)
   {
       if(s[0] == s2[i]){return c;}

   }
   c++;
   for(i=0; s3[i]!='\0' ;i++)
   {
       if(s[0] == s3[i]) {return c;}

   }

}

int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    string s;
    int n,sum=0,a,a1;
    cin>>n;
    for( int i=1; i<=n; i++){
        cin>>s;
        a=check(s);
        cout<<"a"<<a<<endl;
        sum += a;
    }
    cout<<sum<<endl;
    return 0;
}
