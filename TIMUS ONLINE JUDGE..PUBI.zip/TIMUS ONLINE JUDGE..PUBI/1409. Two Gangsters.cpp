#include<bits/stdc++.h>
using namespace std;
int main()
{
    int h,l;
    cin>>h>>l;
    cout<<l-1<<" "<<h-1<<endl;
    return 0;
}
