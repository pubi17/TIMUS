#include<bits/stdc++.h>
using namespace std;

int box (char a)
{
    switch (a)
    {
    case 'A' : case 'P' : case 'O': case 'R':
        return 1;
    case 'B' : case 'M' : case 'S':
        return 2;
    default :
        return 3;

    }
}
int main()
{
    int n;
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    cin>>n;
    string a;
    vector <char> f(n);

    for( int i=0; i<n; i++)
    {
        cin >> a;
        f[i] = a[0];
    }

    int steps =0;
    int pos = 1;
    for(int i=0; i<n; i++)
    {
        steps += abs (pos - box (f[i]));
        pos = box (f[i]);
    }
    cout << steps <<endl;
    return 0;
}
