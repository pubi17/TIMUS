#include<bits/stdc++.h>
using namespace std;
const float pi = 2*acos(0.0);
float dist(float x1, float y1, float x2,float y2)
{
    float dx=x1-x2;
    float dy=y1-y2;
    return sqrt(dx*dx + dy*dy);
}
int main()
{
    int n,i;
    float r;
    ios::sync_with_stdio();
    cin>>n>>r;
    float points[n][2],len=0;
    for(i=0; i<n; i++)
    {
        cin>>points[i][0]>>points[i][1];
        if(i>0)
        {
           len+= dist(points[i][0],points[i][1],points[i-1][0],points[i-1][1]);
        }
    }
    len+=dist(points[0][0],points[0][1],points[n-1][0],points[n-1][1]);
    len+=2.0*pi*r;
    cout<<fixed<<setprecision(2)<<len<<endl;
    return 0;
}
